	<?php $to = "prabindh@gpupowered.org";
	$subject = "Mail from Cyan";
	$txt = "Hello from Cyan!";
	$headers = "From: info@gpupowered.org" . "\r\n";
	$headers .= "Reply-To: info@gpupowered.org" . "\r\n";
	$ret = mail($to,$subject,$txt,$headers);
	if($ret === TRUE) echo "mail success"; else echo "mail failure err =".$ret;
	?>
