function test2_callback()
{
	try
	{
		if(uniqueNameisLoaded == true)
			document.getElementById("demo").innerHTML = (x !== "5") ? "LOADED-PASS" : "LOADED-FAIL";
	}
	catch (err)
	{
		//Too early, just wait
	}
}

test2_callback();
