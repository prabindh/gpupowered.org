var x = 5;

var uniqueNameisLoaded = true;
try
{
	test2_callback();
}
catch (err)
{
	//Too early, just wait
}
